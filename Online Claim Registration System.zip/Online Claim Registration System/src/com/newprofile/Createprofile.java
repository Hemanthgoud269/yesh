package com.newprofile;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.CommonConnection.Commonconnection;

public class Createprofile extends HttpServlet{
Connection c;
	
	ResultSet rs=null;
	PreparedStatement ps=null;
	String str=null;
	RequestDispatcher rd=null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			 c=Commonconnection.getCon();
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String id1=request.getParameter("username");
		String password1=request.getParameter("password");
		String role=request.getParameter("role1");
	/*System.out.println(id1);
	System.out.println(password1);
	System.out.println(role);*/
		ps=c.prepareStatement("insert into userrole values(?,?,?)");
		ps.setString(1, id1);
        ps.setString(2, password1);
        ps.setString(3, role);
        ps.executeUpdate();
    	System.out.println("Added one user into database");
		}
		catch (Exception e) {
			
			e.printStackTrace();
		} 
	}
	}
